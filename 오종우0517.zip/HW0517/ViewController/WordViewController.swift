//
//  WordViewController.swift
//  HW0517
//
//  Created by J Oh on 5/18/24.
//

import UIKit

class WordViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet var searchTextField: UITextField!
    @IBOutlet var searchButton: UIButton!
    
    @IBOutlet var search1Label: UILabel!
    @IBOutlet var search2Label: UILabel!
    @IBOutlet var search3Label: UILabel!
    @IBOutlet var search4Label: UILabel!
    
    
    @IBOutlet var resultBackgroundImageView: UIImageView!
    
    @IBOutlet var resultLabel: UILabel!
    
    let searchDic = ["삼귀자": "연애를 시작하기 전 썸 단계!",
                     "윰차": "1. 유명인과 무명인을 차별한다는 뜻\n2. 유모차",
                     "실매": "실시간 매니저",
                     "만반잘부": "만나서 반가워 잘 부탁해!",
                     "꾸안꾸": "꾸민듯 안꾸민듯 자연스러운 모습",
                     "꾸웨엑": "후회해",
                     "내또출": "내일 또 출근함"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        search1Label.text = "삼귀자"
        search1Label.layer.cornerRadius = 5
        search1Label.layer.borderWidth = 1
        search1Label.textAlignment = .center
        search2Label.text = "실매"
        search2Label.layer.cornerRadius = 5
        search2Label.layer.borderWidth = 1
        search2Label.textAlignment = .center
        search3Label.text = "꾸안꾸"
        search3Label.layer.cornerRadius = 5
        search3Label.layer.borderWidth = 1
        search3Label.textAlignment = .center
        search4Label.text = "내또출"
        search4Label.layer.cornerRadius = 5
        search4Label.layer.borderWidth = 1
        search4Label.textAlignment = .center
        
        
        searchTextField.delegate = self
        searchTextField.placeholder = " 신조어를 검색해보세요"
        searchTextField.borderStyle = .line
        searchTextField.returnKeyType = .search
        
        searchButton.setTitle("", for: .normal)
        searchButton.setImage(UIImage(systemName: "magnifyingglass"), for: .normal)
        searchButton.backgroundColor = .black
        searchButton.tintColor = .white
        
        resultBackgroundImageView.image = .background
        resultBackgroundImageView.backgroundColor = .clear
        resultBackgroundImageView.contentMode = .scaleAspectFill
        
        resultLabel.text = ""
        resultLabel.numberOfLines = 0

        
    }
    

    @IBAction func searchButtonTapped(_ sender: UIButton) {
        search()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        search()
        textField.resignFirstResponder()
        return true
    }
    
    func search() {
        let searchText = searchTextField.text!
        if let result = searchDic[searchText] {
            resultLabel.text = result
        } else if searchText == "" {
            resultLabel.text = "검색어를 입력하세요"
        } else {
            resultLabel.text = "검색 결과가 없습니다..."
        }
        searchTextField.endEditing(true)
        
        let list = Array(searchDic.keys).shuffled()
        search1Label.text = list[0]
        search2Label.text = list[1]
        search3Label.text = list[2]
        search4Label.text = list[3]
        
    }
}
 
