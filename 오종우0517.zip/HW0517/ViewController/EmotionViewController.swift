//
//  EmotionViewController.swift
//  HW0517
//
//  Created by J Oh on 5/18/24.
//

import UIKit

class EmotionViewController: UIViewController {
    
    @IBOutlet var barItemButton: UIBarButtonItem!
    
    @IBOutlet var emotion1Button: UIButton!
    @IBOutlet var emotion2Button: UIButton!
    @IBOutlet var emotion3Button: UIButton!
    @IBOutlet var emotion4Button: UIButton!
    @IBOutlet var emotion5Button: UIButton!
    @IBOutlet var emotion6Button: UIButton!
    @IBOutlet var emotion7Button: UIButton!
    @IBOutlet var emotion8Button: UIButton!
    @IBOutlet var emotion9Button: UIButton!
    
    @IBOutlet var emotion1Label: UILabel!
    @IBOutlet var emotion2Label: UILabel!
    @IBOutlet var emotion3Label: UILabel!
    @IBOutlet var emotion4Label: UILabel!
    @IBOutlet var emotion5Label: UILabel!
    @IBOutlet var emotion6Label: UILabel!
    @IBOutlet var emotion7Label: UILabel!
    @IBOutlet var emotion8Label: UILabel!
    @IBOutlet var emotion9Label: UILabel!
    
    var count: [Int] = [0,0,0,0,0,0]
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        barItemButton.tintColor = .black
        
        emotion1Button.setImage(.slime1, for: .normal)
        emotion1Button.setTitle("", for: .normal)
        emotion1Button.contentMode = .scaleAspectFit
        emotion2Button.setImage(.slime2, for: .normal)
        emotion2Button.setTitle("", for: .normal)
        emotion2Button.contentMode = .scaleAspectFit
        emotion3Button.setImage(.slime3, for: .normal)
        emotion3Button.setTitle("", for: .normal)
        emotion3Button.contentMode = .scaleAspectFit
        emotion4Button.setImage(.slime4, for: .normal)
        emotion4Button.setTitle("", for: .normal)
        emotion4Button.contentMode = .scaleAspectFit
        emotion5Button.setImage(.slime5, for: .normal)
        emotion5Button.setTitle("", for: .normal)
        emotion5Button.contentMode = .scaleAspectFit
        emotion6Button.setImage(.slime6, for: .normal)
        emotion6Button.setTitle("", for: .normal)
        emotion6Button.contentMode = .scaleAspectFit
        emotion7Button.setImage(.slime7, for: .normal)
        emotion7Button.setTitle("", for: .normal)
        emotion7Button.contentMode = .scaleAspectFit
        emotion8Button.setImage(.slime8, for: .normal)
        emotion8Button.setTitle("", for: .normal)
        emotion8Button.contentMode = .scaleAspectFit
        emotion9Button.setImage(.slime9, for: .normal)
        emotion9Button.setTitle("", for: .normal)
        emotion9Button.contentMode = .scaleAspectFit
        
        emotion1Label.text = "행복해 \(count[0])"
        emotion1Label.textAlignment = .center
        emotion1Label.textColor = .black
        emotion2Label.text = "좋아해 \(count[1])"
        emotion2Label.textAlignment = .center
        emotion2Label.textColor = .black
        emotion3Label.text = "사랑해 \(count[2])"
        emotion3Label.textAlignment = .center
        emotion3Label.textColor = .black
        emotion4Label.text = "당황해 \(count[3])"
        emotion4Label.textAlignment = .center
        emotion4Label.textColor = .black
        emotion5Label.text = "속상해 \(count[4])"
        emotion5Label.textAlignment = .center
        emotion5Label.textColor = .black
        emotion6Label.text = "안심해 \(count[5])"
        emotion6Label.textAlignment = .center
        emotion6Label.textColor = .black
        emotion7Label.text = "우울해 0"
        emotion7Label.textAlignment = .center
        emotion7Label.textColor = .black
        emotion8Label.text = "행복해 0"
        emotion8Label.textAlignment = .center
        emotion8Label.textColor = .black
        emotion9Label.text = "슬퍼 0"
        emotion9Label.textAlignment = .center
        emotion9Label.textColor = .black
        
    }
    

    @IBAction func emotion1Tapped(_ sender: UIButton) {
        count[0] += 1
        emotion1Label.text = "행복해 \(count[0])"
    }
    
    @IBAction func emotion2Tapped(_ sender: UIButton) {
        count[1] += 1
        emotion2Label.text = "좋아해 \(count[1])"
    }
    
    @IBAction func emotion3Tapped(_ sender: UIButton) {
        count[2] += 1
        emotion3Label.text = "사랑해 \(count[2])"
    }
    
    @IBAction func emotion4Tapped(_ sender: UIButton) {
        count[3] += 1
        emotion4Label.text = "당황해 \(count[3])"
    }
    
    @IBAction func emotion5Tapped(_ sender: UIButton) {
        count[4] += 1
        emotion5Label.text = "속상해 \(count[4])"
    }
    
    @IBAction func emotion6Tapped(_ sender: UIButton) {
        count[5] += 1
        emotion6Label.text = "안심해 \(count[5])"
    }
    
    @IBAction func emotion7Tapped(_ sender: UIButton) {
        let randomNumber = Int.random(in: 1...100)
        emotion7Label.text = "우울해 \(randomNumber)"
    }
    
    @IBAction func emotion8Tapped(_ sender: UIButton) {
        let randomNumber = Int.random(in: 1...100)
        emotion8Label.text = "행복해 \(randomNumber)"
    }
    
    @IBAction func emotion9Tapped(_ sender: UIButton) {
        let randomNumber = Int.random(in: 1...100)
        emotion9Label.text = "슬퍼 \(randomNumber)"
    }
    
    
    
    
    
    

}
